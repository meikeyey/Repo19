# plugin.close.kodi
A Force Close addon 

Contains Code inspired by @Surfacingx The Creator of the Aftermath Wizard

Also Contains Code From a Freaktab Dev I dont Remember who but IF they want to come forward I will add your credits (Android Force 

CloseFix bundled into old method) The Code Was included more for historical purposes, this was in my original version of this that was never released 

#Features:

Force Close Kodi (Near Flawless Method)

Instant Kill (Using Flawless method)

Old Method From Classic Wizards (With The Force Close method from a certain freaktab dev)

Instant kill (using old method)


Disclaimer: I Cannot and Will not Be Responsibile for any type of negitive activity/consequence that may result from the use of this addon.
