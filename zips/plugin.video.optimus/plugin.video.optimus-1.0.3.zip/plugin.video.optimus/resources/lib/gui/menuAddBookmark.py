import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.Optimus/?site=cFav&function=setBookmark)", True)
